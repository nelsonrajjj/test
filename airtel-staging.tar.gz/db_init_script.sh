# INIT DB
CONTAINER=`docker ps | grep "cassandra" | head -1 | awk '{print $1}'`
if [ -z "$CONTAINER" ]; then
    echo "Cassandra not running"
    exit 1
fi
SALT="sadmsymmetric_keybedU"
HASH="3aeb801c138dca2777ba561b7b03f0cb447c2898ad2002be7e7d63d050f5c778"
docker exec $CONTAINER cqlsh -e "INSERT INTO admin.current (type,customer,id,name,timestamp,system_time,common__privileges,common__pass,common__salt,common__email,common__dashboards) VALUES ('user','all','sysadmin','Admin',0,0,'provider,admin','$HASH','$SALT','','');"
docker exec $CONTAINER cqlsh -e "INSERT INTO config.string_search (type,attr,value,id,customer) VALUES ('user','id','sysadmin','sysadmin','all');"
docker exec $CONTAINER cqlsh -e "INSERT INTO config.string_search (type,attr,value,id,customer) VALUES ('user','customer','all','sysadmin','all');"
SALT="devesymmetric_keybedU"
HASH="03f8b00999698a2a7b3861e19bcaadb5a517946109baa71c980169a8961fee3e"
docker exec $CONTAINER cqlsh -e "INSERT INTO admin.current (type,customer,id,name,timestamp,system_time,common__privileges,common__pass,common__salt,common__email,common__dashboards) VALUES ('user','all','devel','Admin',0,0,'provider,admin,dev','$HASH','$SALT','','');"
docker exec $CONTAINER cqlsh -e "INSERT INTO config.string_search (type,attr,value,id,customer) VALUES ('user','id','devel','devel','all');"
docker exec $CONTAINER cqlsh -e "INSERT INTO config.string_search (type,attr,value,id,customer) VALUES ('user','customer','all','devel','all');"
