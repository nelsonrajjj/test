#!/bin/bash
export SECRETS_VERSION=1

docker stack deploy swarm --with-registry-auth --compose-file $1
