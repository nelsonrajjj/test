firewall-cmd --permanent --add-port=4200/tcp
firewall-cmd --permanent --add-port=4400/tcp
firewall-cmd --permanent --add-port=8099/tcp
firewall-cmd --permanent --add-port=1883/tcp
