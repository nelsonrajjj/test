version: '3.7'

services:
  status_script:
    image: ecloud.embedur.com/status_script:1.0-2-g98d200d
    environment:
      - PROMETHEUS_URL=http://prometheus:9090/api/v1/
      - "FROM_ADDRESS=cloud_support@embedur.com"
      - "SMTP_USER=cloud_support@embedur.com"
      - "SMTP_SERVER=smtp.office365.com"
      - "SMTP_PORT=587"
#      - INTERVAL=60
      - "TO_ADDRESSES=product_cloud_infra@embedur.com,s2.praveen@airtel.com,rupesh.fofaria@airtel.com,ashwin.ravindra@airtel.com,harasees.nanda@airtel.com"
      - VAULT_SERVER=http://vault_server1:8200
      - NETWORK_CIDR=10.0.1.0/24
      - OFFSET=12600
    volumes:
      - type: tmpfs
        target: /config
        tmpfs:
         size: 10000000
    secrets:
      - token
      - role_id

secrets:
 token:
  external: true
  name: status_script_token_${SECRETS_VERSION}
 role_id:
  external: true
  name: status_script_app_role_${SECRETS_VERSION}

