for i in `cat names`
do

ECLOUD=34.194.193.152:5000
LOCAL=172.31.112.145:5000

docker pull "$ECLOUD"/"$i"
docker tag "$ECLOUD"/"$i" "$LOCAL"/"$i"
docker push "$LOCAL"/"$i"
done

